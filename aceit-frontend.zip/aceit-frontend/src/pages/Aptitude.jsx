import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Aptitude = () => {
  const [questions, setQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState({});
  const [score, setScore] = useState(null);
  const [timeLeft, setTimeLeft] = useState(1800); // 30 minutes in seconds
  const navigate = useNavigate();

  // Sample aptitude questions
  const sampleQuestions = [
    {
      id: 1,
      question: "What is 15% of 200?",
      options: ["15", "30", "25", "20"],
      correct: 1,
      type: "quantitative",
      explanation: "15% of 200 = (15/100) × 200 = 30"
    },
    {
      id: 2,
      question: "If a train travels 300 km in 3 hours, what is its speed?",
      options: ["100 km/h", "90 km/h", "110 km/h", "120 km/h"],
      correct: 0,
      type: "quantitative",
      explanation: "Speed = Distance/Time = 300/3 = 100 km/h"
    },
    {
      id: 3,
      question: "Complete the sequence: 2, 6, 18, 54, ?",
      options: ["108", "162", "216", "172"],
      correct: 1,
      type: "logical",
      explanation: "Each number is multiplied by 3: 2×3=6, 6×3=18, 18×3=54, 54×3=162"
    },
    {
      id: 4,
      question: "Which word is different from the others?",
      options: ["Apple", "Banana", "Carrot", "Orange"],
      correct: 2,
      type: "verbal",
      explanation: "Carrot is a vegetable, while others are fruits"
    },
    {
      id: 5,
      question: "If all roses are flowers and some flowers fade quickly, which statement must be true?",
      options: [
        "All roses fade quickly",
        "Some roses fade quickly", 
        "No roses fade quickly",
        "Some flowers that fade quickly are roses"
      ],
      correct: 3,
      type: "logical",
      explanation: "Since some flowers fade quickly and roses are flowers, it's possible some roses fade quickly"
    }
  ];

  useEffect(() => {
    setQuestions(sampleQuestions);
    
    // Timer countdown
    const timer = setInterval(() => {
      setTimeLeft(prev => prev > 0 ? prev - 1 : 0);
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  const handleAnswer = (questionId, answerIndex) => {
    setAnswers(prev => ({ ...prev, [questionId]: answerIndex }));
  };

  const calculateScore = () => {
    let correct = 0;
    questions.forEach(q => {
      if (answers[q.id] === q.correct) {
        correct++;
      }
    });
    setScore({
      correct,
      total: questions.length,
      percentage: (correct / questions.length) * 100
    });
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  if (score !== null) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <div className={`w-24 h-24 mx-auto mb-6 rounded-full flex items-center justify-center text-2xl font-bold ${
            score.percentage >= 70 ? 'bg-green-100 text-green-600' : 
            score.percentage >= 50 ? 'bg-yellow-100 text-yellow-600' : 'bg-red-100 text-red-600'
          }`}>
            {score.percentage.toFixed(0)}%
          </div>
          
          <h2 className="text-3xl font-bold mb-4">Test Completed!</h2>
          <p className="text-xl text-gray-600 mb-6">
            You scored {score.correct} out of {score.total} questions correctly
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{score.correct}</div>
              <div className="text-gray-600">Correct</div>
            </div>
            <div className="bg-red-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{score.total - score.correct}</div>
              <div className="text-gray-600">Incorrect</div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{score.percentage.toFixed(1)}%</div>
              <div className="text-gray-600">Score</div>
            </div>
          </div>

          <div className="flex gap-4 justify-center">
            <button 
              onClick={() => { setScore(null); setCurrentQuestion(0); setAnswers({}); setTimeLeft(1800); }}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
            >
              Retake Test
            </button>
            <button 
              onClick={() => navigate('/')}
              className="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (questions.length === 0) {
    return <div className="p-6">Loading questions...</div>;
  }

  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="p-6 max-w-4xl mx-auto">
      {/* Header with timer and progress */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Aptitude Practice Test</h2>
          <div className="bg-red-100 text-red-600 px-3 py-1 rounded-full font-semibold">
            Time: {formatTime(timeLeft)}
          </div>
        </div>
        
        <div className="flex justify-between items-center text-sm text-gray-600 mb-2">
          <span>Question {currentQuestion + 1} of {questions.length}</span>
          <span>{question.type.toUpperCase()}</span>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-blue-600 h-2 rounded-full transition-all duration-300" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <h3 className="text-lg font-semibold mb-4">{question.question}</h3>
        
        <div className="space-y-3">
          {question.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(question.id, index)}
              className={`w-full text-left p-4 rounded-lg border transition-all ${
                answers[question.id] === index 
                  ? 'bg-blue-100 border-blue-500 text-blue-700' 
                  : 'border-gray-300 hover:bg-gray-50 hover:border-gray-400'
              }`}
            >
              <span className="font-medium mr-2">{String.fromCharCode(65 + index)}.</span>
              {option}
            </button>
          ))}
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between">
        <button
          onClick={() => setCurrentQuestion(prev => Math.max(0, prev - 1))}
          disabled={currentQuestion === 0}
          className="bg-gray-500 text-white px-6 py-2 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-600"
        >
          Previous
        </button>
        
        {currentQuestion === questions.length - 1 ? (
          <button
            onClick={calculateScore}
            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
          >
            Submit Test
          </button>
        ) : (
          <button
            onClick={() => setCurrentQuestion(prev => prev + 1)}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
          >
            Next Question
          </button>
        )}
      </div>
    </div>
  );
};

export default Aptitude;