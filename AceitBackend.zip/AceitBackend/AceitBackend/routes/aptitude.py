from fastapi import APIRouter
from database import questions_collection, progress_collection
from datetime import datetime

router = APIRouter()

# Get aptitude questions for the test
@router.get("/questions")
async def get_aptitude_questions(topic: str = None):
    """Get aptitude questions"""
    from database import get_aptitude_questions
    
    questions = get_aptitude_questions()
    
    # Filter by topic if provided
    if topic:
        questions = [q for q in questions if q.get('topic') == topic]
    
    # Remove correct_answer from response
    for question in questions:
        if 'correct_answer' in question:
            del question['correct_answer']
    
    return questions

# Submit answers and calculate score
@router.post("/submit")
async def submit_answers(answers: dict):
    """
    Submit user answers and calculate score
    Expected input: {"user_id": "123", "answers": {"apt1": 1, "apt2": 0}}
    """
    from database import questions_data, progress_data
    
    user_id = answers.get("user_id")
    user_answers = answers.get("answers", {})
    
    score = 0
    total_questions = len(user_answers)
    
    # Check each answer
    for question_id, user_answer in user_answers.items():
        # Find the question in the list
        question = next((q for q in questions_data if q.get("id") == question_id), None)
        
        # If question exists and user answer is correct
        if question and question.get("correct_answer") == user_answer:
            score += 1
    
    # Calculate percentage
    percentage = (score / total_questions) * 100 if total_questions > 0 else 0
    
    # Save progress to database
    progress_data.append({
        "user_id": user_id,
        "module": "aptitude",
        "score": score,
        "total_questions": total_questions,
        "percentage": percentage,
        "timestamp": datetime.utcnow()
    })
    
    return {
        "score": score,
        "total_questions": total_questions, 
        "percentage": round(percentage, 2),
        "message": f"You scored {score}/{total_questions} ({round(percentage, 2)}%)"
    }