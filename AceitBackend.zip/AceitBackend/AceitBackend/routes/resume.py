from fastapi import APIRouter, UploadFile, File, Form
import re
from datetime import datetime
from database import progress_data

router = APIRouter()

# Required skills for different job roles
JOB_ROLE_SKILLS = {
    "software_developer": ["python", "java", "javascript", "sql", "git", "rest api", "docker"],
    "data_scientist": ["python", "r", "sql", "machine learning", "statistics", "pandas", "numpy"],
    "frontend_developer": ["javascript", "react", "html", "css", "typescript", "redux"],
    "backend_developer": ["python", "java", "node.js", "sql", "mongodb", "aws", "docker"]
}

@router.post("/analyze")
async def analyze_resume(
    job_role: str = Form(...),
    user_id: str = Form(...),
    resume_text: str = Form(...)  # For demo - in real app, process PDF file
):
    """
    Analyze resume against job role requirements
    """
    analysis = analyze_resume_content(resume_text, job_role)
    
    # Save progress
    progress_data.append({
        "user_id": user_id,
        "module": "resume_analysis",
        "score": analysis["match_score"],
        "timestamp": datetime.utcnow(),
        "job_role": job_role,
        "analysis": analysis
    })
    
    return analysis

def analyze_resume_content(resume_text: str, job_role: str):
    """Analyze resume content"""
    resume_text_lower = resume_text.lower()
    
    # Get required skills for the job role
    required_skills = JOB_ROLE_SKILLS.get(job_role, [])
    
    # Find matching skills
    matched_skills = []
    missing_skills = []
    
    for skill in required_skills:
        if skill in resume_text_lower:
            matched_skills.append(skill)
        else:
            missing_skills.append(skill)
    
    # Calculate match score
    if required_skills:
        match_score = (len(matched_skills) / len(required_skills)) * 100
    else:
        match_score = 0
    
    # Extract other information
    experience = extract_experience(resume_text)
    education = extract_education(resume_text)
    projects = extract_projects(resume_text)
    
    # Generate suggestions
    suggestions = generate_resume_suggestions(matched_skills, missing_skills, experience)
    
    return {
        "match_score": round(match_score, 2),
        "job_role": job_role,
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
        "experience_years": experience,
        "education": education,
        "projects_count": projects,
        "suggestions": suggestions,
        "overall_feedback": generate_overall_feedback(match_score)
    }

def extract_experience(resume_text: str):
    """Extract years of experience from resume"""
    # Simple pattern matching for experience
    experience_patterns = [
        r'(\d+)\+?\s*years?',
        r'experience.*?(\d+)\+?\s*years?',
        r'(\d+)\+?\s*years?.*?experience'
    ]
    
    for pattern in experience_patterns:
        match = re.search(pattern, resume_text.lower())
        if match:
            return int(match.group(1))
    
    return 0  # Default if not found

def extract_education(resume_text: str):
    """Extract education information"""
    education_keywords = ["bachelor", "master", "phd", "degree", "university", "college"]
    found_education = [word for word in education_keywords if word in resume_text.lower()]
    return found_education

def extract_projects(resume_text: str):
    """Count project mentions"""
    project_keywords = ["project", "developed", "built", "created", "implemented"]
    project_count = sum(1 for word in project_keywords if word in resume_text.lower())
    return project_count

def generate_resume_suggestions(matched_skills: list, missing_skills: list, experience: int):
    """Generate resume improvement suggestions"""
    suggestions = []
    
    if missing_skills:
        suggestions.append(f"Add these skills: {', '.join(missing_skills)}")
    
    if experience < 2:
        suggestions.append("Highlight personal projects and internships to compensate for limited experience")
    
    if len(matched_skills) < 5:
        suggestions.append("Include more technical skills and tools you're familiar with")
    
    if not suggestions:
        suggestions.append("Your resume looks strong! Consider adding quantifiable achievements")
    
    return suggestions

def generate_overall_feedback(match_score: float):
    """Generate overall feedback based on match score"""
    if match_score >= 80:
        return "Excellent match! Your resume is well-aligned with the job requirements."
    elif match_score >= 60:
        return "Good match. Consider adding a few more relevant skills."
    elif match_score >= 40:
        return "Moderate match. Significant improvements needed in skills section."
    else:
        return "Poor match. Major revisions needed to align with job requirements."

@router.get("/job-roles")
async def get_job_roles():
    """Get available job roles for analysis"""
    return list(JOB_ROLE_SKILLS.keys())