# Massive Question Database
users_data = []
questions_data = []
progress_data = []

from massive_database import massive_db

def load_massive_database():
    """Load questions from massive database"""
    global questions_data
    
    print("🚀 LOADING MASSIVE QUESTION DATABASE...")
    
    # Get all questions from massive database
    coding_problems = massive_db.datasets["coding"]
    aptitude_questions = massive_db.datasets["aptitude"] 
    interview_questions = massive_db.datasets["interview"]
    
    # Combine all questions
    questions_data.clear()
    questions_data.extend(coding_problems)
    questions_data.extend(aptitude_questions)
    questions_data.extend(interview_questions)
    
    print("🎉 MASSIVE DATABASE LOADED SUCCESSFULLY!")
    print(f"📊 BREAKDOWN:")
    print(f"   - Coding Problems: {len(coding_problems)}")
    print(f"   - Aptitude Questions: {len(aptitude_questions)}")
    print(f"   - Interview Questions: {len(interview_questions)}")
    print(f"   - TOTAL: {len(questions_data)} questions")

# Database functions
def get_aptitude_questions():
    return [q for q in questions_data if 'options' in q]

def get_coding_problems():
    return [q for q in questions_data if 'title' in q]

def find_user_by_email(email):
    return next((u for u in users_data if u.get('email') == email), None)

def add_user(user_data):
    users_data.append(user_data)
    return True

def add_progress(progress_data_item):
    progress_data.append(progress_data_item)
    return True

# Load massive database
load_massive_database()

# Export collections
users_collection = users_data
questions_collection = questions_data  
progress_collection = progress_data