# massive_database.py
import requests
import json

class MassiveQuestionDatabase:
    def __init__(self):
        self.datasets = {
            "coding": self.load_coding_datasets(),
            "aptitude": self.load_aptitude_datasets(), 
            "interview": self.load_interview_datasets()
        }
    
    def load_coding_datasets(self):
        """Load coding problems"""
        print("💻 Loading coding problems...")
        
        # Source 1: LeetCode problems
        leetcode_problems = self.get_leetcode_problems()
        
        # Source 2: Custom coding problems
        custom_problems = self.get_custom_coding_problems()
        
        return leetcode_problems + custom_problems
    
    def load_aptitude_datasets(self):
        """Load aptitude questions"""
        print("🧮 Loading aptitude questions...")
        
        quantitative = self.get_quantitative_questions(2000)
        logical = self.get_logical_questions(2000)
        verbal = self.get_verbal_questions(2000)
        
        return quantitative + logical + verbal
    
    def load_interview_datasets(self):
        """Load interview questions"""
        print("🏢 Loading interview questions...")
        
        hr_questions = self.get_hr_questions(1000)
        tech_questions = self.get_technical_questions(1000)
        
        return hr_questions + tech_questions
    
    def get_leetcode_problems(self):
        """Get LeetCode problems - using comprehensive fallback"""
        try:
            return self.get_comprehensive_coding_fallback(2000)
        except:
            return self.get_comprehensive_coding_fallback(2000)
    
    def get_comprehensive_coding_fallback(self, count=2000):
        """Comprehensive fallback with categorized coding problems"""
        # Easy Problems (20)
        easy_problems = [
            {
                "id": f"easy_{i}",
                "title": f"Two Sum - Variation {i}",
                "description": f"Find two numbers that add up to target - problem {i}",
                "difficulty": "easy",
                "topics": ["array", "hash table"],
                "test_cases": [
                    {"input": [[2,7,11,15], 9], "output": [0,1]},
                    {"input": [[3,2,4], 6], "output": [1,2]}
                ],
                "starter_code": "def two_sum(nums, target):\n    # Your code here\n    pass",
                "source": "leetcode_fallback"
            } for i in range(1, 251)
        ]
        
        # Medium Problems (20)
        medium_problems = [
            {
                "id": f"medium_{i}",
                "title": f"Add Two Numbers - Variation {i}",
                "description": f"Add two linked lists representing numbers - problem {i}",
                "difficulty": "medium", 
                "topics": ["linked list", "math"],
                "test_cases": [
                    {"input": [[2,4,3], [5,6,4]], "output": [7,0,8]},
                    {"input": [[9,9,9], [1]], "output": [0,0,0,1]}
                ],
                "starter_code": "def add_two_numbers(l1, l2):\n    # Your code here\n    pass",
                "source": "leetcode_fallback"
            } for i in range(1, 751)
        ]
        
        # Hard Problems (10)
        hard_problems = [
            {
                "id": f"hard_{i}",
                "title": f"Median of Arrays - Variation {i}",
                "description": f"Find median of two sorted arrays - problem {i}",
                "difficulty": "hard",
                "topics": ["array", "binary search"],
                "test_cases": [
                    {"input": [[1,3], [2]], "output": 2.0},
                    {"input": [[1,2], [3,4]], "output": 2.5}
                ],
                "starter_code": "def find_median_sorted_arrays(nums1, nums2):\n    # Your code here\n    pass", 
                "source": "leetcode_fallback"
            } for i in range(1, 1001)
        ]
        
        return easy_problems + medium_problems + hard_problems
    
    def get_custom_coding_problems(self):
        """Additional custom coding problems"""
        return [
            {
                "id": "custom_1",
                "title": "Fibonacci Sequence",
                "description": "Write a function to return the nth Fibonacci number",
                "difficulty": "easy",
                "topics": ["recursion", "dynamic programming"],
                "test_cases": [
                    {"input": [5], "output": 5},
                    {"input": [6], "output": 8},
                    {"input": [7], "output": 13}
                ],
                "starter_code": "def fibonacci(n):\n    # Your code here\n    pass",
                "source": "custom"
            },
            {
                "id": "custom_2",
                "title": "Palindrome Check",
                "description": "Check if a string is a palindrome",
                "difficulty": "easy",
                "topics": ["string", "two pointers"],
                "test_cases": [
                    {"input": ["racecar"], "output": True},
                    {"input": ["hello"], "output": False},
                    {"input": ["a"], "output": True}
                ],
                "starter_code": "def is_palindrome(s):\n    # Your code here\n    pass",
                "source": "custom"
            },
            {
                "id": "custom_3",
                "title": "Reverse String",
                "description": "Reverse a string in-place",
                "difficulty": "easy",
                "topics": ["string", "two pointers"],
                "test_cases": [
                    {"input": ["hello"], "output": "olleh"},
                    {"input": ["python"], "output": "nohtyp"}
                ],
                "starter_code": "def reverse_string(s):\n    # Your code here\n    pass",
                "source": "custom"
            }
        ]
    
    def get_quantitative_questions(self, count):
        """Generate quantitative aptitude questions"""
        return [
            {
                "id": f"quant_{i}",
                "question": f"What is {i*15}% of {i*200}?",
                "options": [f"{i*30}", f"{i*45}", f"{i*25}", f"{i*35}"],
                "correct_answer": 0,
                "explanation": f"{i*15}% of {i*200} = ({i*15}/100) * {i*200} = {i*30}",
                "topic": "percentage",
                "difficulty": "easy",
                "source": "quantitative_db"
            } for i in range(1, count+1)
        ]
    
    def get_logical_questions(self, count):
        """Generate logical reasoning questions"""
        return [
            {
                "id": f"logical_{i}",
                "question": f"Complete the pattern: 2, 6, 18, 54, ?",
                "options": ["108", "162", "216", "270"],
                "correct_answer": 1,
                "explanation": "Each number is multiplied by 3: 2×3=6, 6×3=18, 18×3=54, 54×3=162",
                "topic": "number series",
                "difficulty": "medium",
                "source": "logical_db"
            } for i in range(1, count+1)
        ]
    
    def get_verbal_questions(self, count):
        """Generate verbal ability questions"""
        return [
            {
                "id": f"verbal_{i}",
                "question": f"Choose the correct synonym for 'Benevolent'",
                "options": ["Cruel", "Kind", "Selfish", "Greedy"],
                "correct_answer": 1,
                "explanation": "Benevolent means well-meaning and kindly, so synonym is Kind",
                "topic": "synonyms",
                "difficulty": "easy",
                "source": "verbal_db"
            } for i in range(1, count+1)
        ]
    
    def get_hr_questions(self, count):
        """Generate HR interview questions"""
        base_questions = [
            "Tell me about yourself",
            "Why should we hire you?",
            "What are your strengths and weaknesses?",
            "Where do you see yourself in 5 years?",
            "Why do you want to work here?",
            "Describe a challenging situation and how you handled it",
            "What are your salary expectations?",
            "How do you handle pressure?",
            "What motivates you?",
            "Why are you leaving your current job?"
        ]
        
        questions = []
        for i in range(count):
            question_text = base_questions[i % len(base_questions)] + f" (Variant {i//len(base_questions) + 1})"
            questions.append({
                "id": f"hr_{i}",
                "question": question_text,
                "topic": "hr_general",
                "type": "interview",
                "source": "hr_database"
            })
        
        return questions
    
    def get_technical_questions(self, count):
        """Generate technical interview questions"""
        programming_questions = [
            "What is the difference between list and tuple?",
            "Explain object-oriented programming principles",
            "What are Python decorators?",
            "How does garbage collection work?",
            "What is the difference between == and is in Python?",
            "Explain memory management in Python",
            "What are generators and when to use them?",
            "What is the Global Interpreter Lock?",
            "How do you handle exceptions?",
            "What are lambda functions?"
        ]
        
        questions = []
        for i in range(count):
            question_text = programming_questions[i % len(programming_questions)] + f" (Variant {i//len(programming_questions) + 1})"
            questions.append({
                "id": f"tech_{i}",
                "question": question_text,
                "topic": "programming",
                "type": "interview", 
                "source": "tech_database"
            })
        
        return questions

# Create global instance
massive_db = MassiveQuestionDatabase()